# Forma global TS types

## Install
```bash
npm install @universe-forma/global-types
```

## Usage
```typescript
import { Analytics } from "@universe-forma/global-types";

const event: Analytics.TrackEventPayload = {...}
```

```typescript
import { Converter, FileFormat } from '@universe-forma/global-types';

const payload = {
    from: FileFormat.PDF,
    to: FileFormat.DOCX,
};
const canConvert = Converter.SupportedConverters[payload.from].includes(
    payload.to,
);
```
