import { ComponentProps, FC } from 'react';
import { List as RadixTabsList } from '@radix-ui/react-tabs';
import { ITabsContext } from './state/tabsContext';
type ITabsListProps = Omit<ComponentProps<typeof RadixTabsList>, keyof ITabsContext> & Partial<ITabsContext>;
export declare const TabsList: FC<ITabsListProps>;
export {};
