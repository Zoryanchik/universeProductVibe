# UI-KIT for all FORMA projects

## How to use the npm private registry

1. To log into the npm private registry, you need to create a personal token. You can do this [here](https://github.com/settings/tokens).

Minimum required scopes:

![Minimal required scopes](/docs/assets/token-settings.png)

2. You can then use this command in the terminal:

```bash
npm login --scope=@universe-forma --auth-type=legacy --registry=https://npm.pkg.github.com

> Username: YOUR_GITHUB_USERNAME (only lowercase e.g. SomeOne -> someone)
> Password: RECEIVED_TOKEN_FROM_THE_STEP_ABOVE
```

---

Read more docs at [github](https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-npm-registry).
