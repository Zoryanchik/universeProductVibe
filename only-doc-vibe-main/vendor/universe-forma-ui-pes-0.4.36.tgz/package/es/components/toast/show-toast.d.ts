import { ComponentProps } from 'react';
import { ToastPosition } from 'react-toastify';
import { Toast } from './Toast';
interface IShowToastParams extends Omit<ComponentProps<typeof Toast>, 'onClose'> {
    /** Set the delay in ms to close the toast automatically. Use false to prevent the toast from closing. Default: 5000 */
    autoClose?: number | false;
    position: ToastPosition;
    containerId?: string;
}
export declare const showToast: ({ autoClose, position, containerId, ...toastParams }: IShowToastParams) => Promise<{
    closeToast: () => void;
    getIsToastActive: () => boolean;
}>;
export {};
