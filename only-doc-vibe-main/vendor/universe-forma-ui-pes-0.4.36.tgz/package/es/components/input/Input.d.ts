import { ComponentProps, ReactNode } from 'react';
type InputProps = Omit<ComponentProps<'input'>, 'size' | 'value'>;
interface IInputProps extends InputProps {
    size: 'dense' | 'lg';
    bg: 'default' | 'filled';
    value?: string;
    isError?: boolean;
    isSuccess?: boolean;
    errorMessage?: string;
    leftIcon?: ReactNode;
    leftText?: string;
    rightIcon?: ReactNode;
    rightText?: string;
    label?: ReactNode;
    helperText?: ReactNode;
    rootClassName?: string;
    containerClassName?: string;
    labelClassName?: string;
    errorMessageClassName?: string;
    helperTextClassName?: string;
}
export declare const Input: import('react').NamedExoticComponent<Omit<IInputProps, "ref"> & import('react').RefAttributes<HTMLInputElement>>;
export {};
