import { ComponentProps, FC, ReactNode } from 'react';
import * as DropdownMenu from '@radix-ui/react-dropdown-menu';
interface IBaseDropdown extends ComponentProps<typeof DropdownMenu.Content> {
    trigger?: ReactNode;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    dir?: 'ltr' | 'rtl';
    modal?: boolean;
}
/** Base Dropdown component without any styling, just animations and controls via props */
export declare const BaseDropdown: FC<IBaseDropdown>;
export {};
