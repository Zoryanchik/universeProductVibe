import { ECurrencyCode, ECurrencySymbol } from '@universe-forma/global-types';
export declare const DEFAULT_CURRENCY = ECurrencyCode.USD;
export interface FormatPriceOptions {
    /** Whether to include currency symbol (default: true) */
    includeSymbol?: boolean;
    /** Optional override for currency symbol (uses user's country symbol) */
    userCurrencySymbol?: string;
    /** Whether the input amount is in cents (default: false) */
    isInCents?: boolean;
    /** Whether to space between the currency symbol and the amount (default: false) */
    spaceBetween?: boolean;
}
export declare const getCurrencySymbol: (currency: string | ECurrencyCode | undefined) => string;
export declare const getCurrencySymbolByCountryCode: (country: string) => ECurrencySymbol;
/**
 * Currency formatting configuration
 */
export interface CurrencyFormatter {
    decimalPlaces: number;
    symbolPosition: 'before' | 'after';
    divisor: number;
    spaceBetween: boolean;
}
/**
 * Register a custom formatter for a currency
 * Useful for adding new currency support without modifying the core logic
 */
export declare const registerCurrencyFormatter: (currencyCode: string, formatter: CurrencyFormatter) => void;
/**
 * Price formatting function
 *
 * @param amount - The price amount (in display format or cents based on isInCents option)
 * @param currency - Currency code (e.g., 'USD', 'JPY', 'EUR')
 * @param options - Formatting options
 * @returns Formatted price string
 */
export declare const formatPrice: (amount: number | undefined | null, currency: string | undefined, options?: FormatPriceOptions) => string;
