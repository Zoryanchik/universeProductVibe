import { ComponentProps } from 'react';
import { Input } from '../input';
interface ISearchProps extends ComponentProps<typeof Input> {
    searchRootClassName?: string;
    cancelText?: string;
    clearText?: string;
    findText?: string;
    showSubmitButton?: boolean;
    onSubmit?: () => void;
    onClear?: () => void;
    onCancel?: () => void;
}
export declare const Search: import('react').NamedExoticComponent<Omit<ISearchProps, "ref"> & import('react').RefAttributes<HTMLInputElement>>;
export {};
