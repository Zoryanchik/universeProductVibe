import { FC, RefObject } from 'react';
interface TabsActiveAnimationProps {
    scrollContainerRef: RefObject<HTMLDivElement> | null;
}
export declare const TabsActiveAnimation: FC<TabsActiveAnimationProps>;
export {};
